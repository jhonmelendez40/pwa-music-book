/* App JS: Maneja vistas, auth en localStorage, canciones y drag&drop + touch */
const app = document.getElementById('app');
const VIEWS = {
  login: '/views/login.html',
  register: '/views/register.html',
  recover: '/views/recover.html',
  main: '/views/main.html'
};

// Simple fetch de vistas (Acode soporta rutas locales)
async function loadView(path){
  const res = await fetch(path);
  return await res.text();
}

// Render inicial: mostrar login si no hay user en session
(async function init(){
  await showView('login');
  attachGlobalHandlers();
})();

async function showView(name){
  const html = await loadView(VIEWS[name]);
  app.innerHTML = html;
  if(name === 'login') bindLogin();
  if(name === 'register') bindRegister();
  if(name === 'recover') bindRecover();
  if(name === 'main') bindMain();
}

function attachGlobalHandlers(){
  // navigate from index if any
}

// ---- Auth using localStorage ----
function usersKey(){return 'pwb_users_v1'}
function sessionKey(){return 'pwb_session_v1'}
function songsKey(user){return `pwb_songs_${user}`}

function getUsers(){return JSON.parse(localStorage.getItem(usersKey())||'{}')}
function saveUsers(u){localStorage.setItem(usersKey(),JSON.stringify(u))}

function bindLogin(){
  document.getElementById('to-register').onclick = ()=>showView('register');
  document.getElementById('to-recover').onclick = ()=>showView('recover');
  document.getElementById('form-login').onsubmit = e=>{
    e.preventDefault();
    const user = document.getElementById('login-user').value.trim();
    const pass = document.getElementById('login-pass').value;
    const users = getUsers();
    if(users[user] && users[user].pass === pass){
      localStorage.setItem(sessionKey(), user);
      showView('main');
    } else alert('Usuario o contraseña incorrectos');
  }
}

function bindRegister(){
  document.getElementById('to-login-from-register').onclick = ()=>showView('login');
  document.getElementById('form-register').onsubmit = e=>{
    e.preventDefault();
    const nombre = document.getElementById('reg-nombre').value.trim();
    const apellido = document.getElementById('reg-apellido').value.trim();
    const user = document.getElementById('reg-user').value.trim();
    const key = document.getElementById('reg-key').value;
    const pass = document.getElementById('reg-pass').value;
    const users = getUsers();
    if(users[user]){alert('Usuario ya existe');return}
    users[user] = {nombre,apellido,key,pass};
    saveUsers(users);
    alert('Registrado con éxito');
    showView('login');
  }
}

function bindRecover(){
  document.getElementById('to-login-from-recover').onclick = ()=>showView('login');
  document.getElementById('form-recover').onsubmit = e=>{
    e.preventDefault();
    const nombre = document.getElementById('rec-nombre').value.trim();
    const apellido = document.getElementById('rec-apellido').value.trim();
    const user = document.getElementById('rec-user').value.trim();
    const key = document.getElementById('rec-key').value;
    const users = getUsers();
    if(users[user] && users[user].nombre===nombre && users[user].apellido===apellido && users[user].key===key){
      alert('La contraseña es: ' + users[user].pass);
      showView('login');
    } else alert('Datos no coinciden');
  }
}

// ---- Main view logic: songs, drag&drop, touch and book view ----
function bindMain(){
  document.getElementById('logout').onclick = ()=>{localStorage.removeItem(sessionKey());showView('login')};
  const user = localStorage.getItem(sessionKey());
  const users = getUsers();
  document.getElementById('user-welcome').textContent = user? `${users[user].nombre} ${users[user].apellido}` : '';

  const listEl = document.getElementById('songs-list');
  const form = document.getElementById('form-song');
  const bookPages = document.getElementById('book-pages');
  const pageIndicator = document.getElementById('page-indicator');
  let songs = JSON.parse(localStorage.getItem(songsKey(user))||'[]');
  let currentPages = []; let currentPageIdx = 0;

  function renderList(){
    listEl.innerHTML='';
    songs.forEach((s,i)=>{
      const li = document.createElement('li');
      li.draggable = true;
      li.dataset.index = i;
      li.tabIndex = 0;
      li.textContent = s.name;
      li.addEventListener('click', ()=>{
        li.classList.toggle('selected');
      });
      // drag events
      li.addEventListener('dragstart', e=>{ li.classList.add('dragging'); e.dataTransfer.setData('text/plain', i); });
      li.addEventListener('dragend', ()=>li.classList.remove('dragging'));
      // touch: long press to toggle selected
      let touchTimer = null;
      li.addEventListener('touchstart', ()=>{ touchTimer = setTimeout(()=>li.classList.toggle('selected'),600)});
      li.addEventListener('touchend', ()=>{ if(touchTimer)clearTimeout(touchTimer)});
      listEl.app